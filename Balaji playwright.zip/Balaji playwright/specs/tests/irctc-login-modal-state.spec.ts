// spec: specs/irctc-login-test-plan.md
// seed: seed.spec.ts

import { test, expect } from '@playwright/test';

test.describe('Modal Closure and Re-opening', () => {

  test('9.1 Close login modal and reopen', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Close the login modal (find and click close button or use Escape)
    // Look for close button in modal or press Escape
    await page.keyboard.press('Escape');
    
    // Wait for modal to close
    await page.waitForTimeout(500);
    
    // Login modal closes and returns to homepage
    await expect(modal).toBeHidden({ timeout: 2000 });
    
    // 4. Click on "LOGIN / REGISTER" button again
    await loginLink.click();
    
    // Login modal appears again with empty form fields
    await expect(modal).toBeVisible();
  });
});

test.describe('Form Reset and Data Retention', () => {

  test('10.1 Verify form clears after modal close and reopen', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Enter 'testuser' in the Username field
    const usernameInput = modal.locator('input[type="text"]');
    await usernameInput.fill('testuser');
    
    // Username field displays 'testuser'
    await expect(usernameInput).toHaveValue('testuser');
    
    // 4. Enter 'TestPassword123' in the Password field
    const passwordInput = modal.locator('input[type="password"]');
    await passwordInput.fill('TestPassword123');
    
    // Password field is masked
    await expect(passwordInput).toHaveValue('TestPassword123');
    
    // 5. Close the login modal
    await page.keyboard.press('Escape');
    
    // Wait for modal to close
    await page.waitForTimeout(500);
    
    // Login modal closes
    await expect(modal).toBeHidden({ timeout: 2000 });
    
    // 6. Click on "LOGIN / REGISTER" button again
    await loginLink.click();
    
    // Wait for modal to reappear
    await page.waitForTimeout(500);
    
    // Login modal appears with empty form fields
    await expect(modal).toBeVisible();
    
    // Username field is empty
    await expect(usernameInput).toHaveValue('');
    
    // Password field is empty
    await expect(passwordInput).toHaveValue('');
  });

  test('10.2 OTP checkbox state after modal close', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Check the "Booking using OTP" checkbox
    const otpCheckbox = modal.locator('input[type="checkbox"]');
    await otpCheckbox.check();
    
    // Checkbox is checked
    await expect(otpCheckbox).toBeChecked();
    
    // 4. Close the login modal
    await page.keyboard.press('Escape');
    
    // Wait for modal to close
    await page.waitForTimeout(500);
    
    // Login modal closes
    await expect(modal).toBeHidden({ timeout: 2000 });
    
    // 5. Click on "LOGIN / REGISTER" button again
    await loginLink.click();
    
    // Wait for modal to reappear
    await page.waitForTimeout(500);
    
    // Login modal appears
    await expect(modal).toBeVisible();
    
    // "Booking using OTP" checkbox is unchecked (reset to default state)
    await expect(otpCheckbox).not.toBeChecked();
  });
});
