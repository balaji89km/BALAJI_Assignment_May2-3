// spec: specs/irctc-login-test-plan.md
// seed: seed.spec.ts

import { test, expect } from '@playwright/test';

test.describe('Username Field Validation', () => {

  test('2.1 Enter valid username format', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    await expect(page).toHaveURL('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Click in the Username field
    const usernameInput = modal.locator('input[type="text"]');
    await expect(usernameInput).toBeVisible();
    await usernameInput.click();
    
    // Username input field is focused
    await expect(usernameInput).toBeFocused();
    
    // 4. Enter 'testuser123' in the Username field
    await usernameInput.fill('testuser123');
    
    // Username field displays 'testuser123'
    await expect(usernameInput).toHaveValue('testuser123');
  });

  test('2.2 Username field accepts various character types', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Enter 'user.test@2024' in the Username field
    const usernameInput = modal.locator('input[type="text"]');
    await usernameInput.fill('user.test@2024');
    
    // Username field displays 'user.test@2024'
    await expect(usernameInput).toHaveValue('user.test@2024');
  });

  test('2.3 Clear and re-enter username', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Enter 'testuser' in the Username field
    const usernameInput = modal.locator('input[type="text"]');
    await usernameInput.fill('testuser');
    
    // Username field displays 'testuser'
    await expect(usernameInput).toHaveValue('testuser');
    
    // 4. Clear the Username field
    await usernameInput.clear();
    
    // Username field is now empty
    await expect(usernameInput).toHaveValue('');
    
    // 5. Enter 'newuser' in the Username field
    await usernameInput.fill('newuser');
    
    // Username field displays 'newuser'
    await expect(usernameInput).toHaveValue('newuser');
  });
});

test.describe('Password Field Validation', () => {

  test('3.1 Enter password in password field', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Click in the Password field
    const passwordInput = modal.locator('input[type="password"]');
    await expect(passwordInput).toBeVisible();
    await passwordInput.click();
    
    // Password input field is focused
    await expect(passwordInput).toBeFocused();
    
    // 4. Enter 'Password123!' in the Password field
    await passwordInput.fill('Password123!');
    
    // Password field is masked/hidden (shows dots or bullets)
    // Verify input type is password (which provides masking)
    await expect(passwordInput).toHaveAttribute('type', 'password');
  });

  test('3.2 Password field masks input for security', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Enter 'MySecurePassword' in the Password field
    const passwordInput = modal.locator('input[type="password"]');
    await passwordInput.fill('MySecurePassword');
    
    // Password characters are not visible in plain text
    // Password field shows masked characters
    await expect(passwordInput).toHaveAttribute('type', 'password');
    // Verify the value is stored (not visible, but accessible)
    await expect(passwordInput).toHaveValue('MySecurePassword');
  });

  test('3.3 Clear and re-enter password', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Enter 'FirstPassword' in the Password field
    const passwordInput = modal.locator('input[type="password"]');
    await passwordInput.fill('FirstPassword');
    
    // Password field is masked
    await expect(passwordInput).toHaveAttribute('type', 'password');
    await expect(passwordInput).toHaveValue('FirstPassword');
    
    // 4. Clear the Password field
    await passwordInput.clear();
    
    // Password field is now empty
    await expect(passwordInput).toHaveValue('');
    
    // 5. Enter 'DifferentPassword' in the Password field
    await passwordInput.fill('DifferentPassword');
    
    // Password field is masked
    await expect(passwordInput).toHaveAttribute('type', 'password');
    await expect(passwordInput).toHaveValue('DifferentPassword');
  });
});
