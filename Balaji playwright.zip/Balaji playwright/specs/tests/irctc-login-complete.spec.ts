// spec: specs/irctc-login-test-plan.md
// seed: seed.spec.ts
// Complete IRCTC Login Page Test Suite

import { test, expect } from '@playwright/test';

test.describe('IRCTC Login Page - Complete Test Suite', () => {

  test.describe('1. Login Modal Interaction', () => {

    test('1.1 - Open login modal successfully', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      await expect(page).toHaveURL('https://www.irctc.co.in/nget/train-search');
      
      const searchButton = page.locator('button:has-text("Search Trains")');
      await expect(searchButton).toBeVisible();
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await expect(loginLink).toBeVisible();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      await expect(modal).toBeVisible();
      
      const signInButton = modal.locator('button:has-text("SIGN IN")');
      await expect(signInButton).toBeVisible();
    });

    test('1.2 - Verify login form elements are present', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      await expect(modal).toBeVisible();
      
      const usernameInput = modal.locator('input[type="text"]');
      await expect(usernameInput).toBeVisible();
      await expect(usernameInput).toHaveAttribute('placeholder', 'User Name');
      
      const passwordInput = modal.locator('input[type="password"]');
      await expect(passwordInput).toBeVisible();
      await expect(passwordInput).toHaveAttribute('placeholder', 'Password');
      
      const otpCheckbox = modal.locator('input[type="checkbox"]');
      await expect(otpCheckbox).toBeVisible();
      
      const signInButton = modal.locator('button:has-text("SIGN IN")');
      await expect(signInButton).toBeVisible();
      
      await expect(modal.locator('text=FORGOT ACCOUNT DETAILS')).toBeVisible();
      await expect(modal.locator('text=REGISTER')).toBeVisible();
      await expect(modal.locator('text=AGENT LOGIN')).toBeVisible();
      await expect(modal.locator('text=Visually impaired')).toBeVisible();
    });
  });

  test.describe('2. Username Field Validation', () => {

    test('2.1 - Enter valid username format', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      await expect(modal).toBeVisible();
      
      const usernameInput = modal.locator('input[type="text"]');
      await usernameInput.click();
      await expect(usernameInput).toBeFocused();
      
      await usernameInput.fill('testuser123');
      await expect(usernameInput).toHaveValue('testuser123');
    });

    test('2.2 - Username accepts various character types', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const usernameInput = modal.locator('input[type="text"]');
      
      await usernameInput.fill('user.test@2024');
      await expect(usernameInput).toHaveValue('user.test@2024');
    });

    test('2.3 - Clear and re-enter username', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const usernameInput = modal.locator('input[type="text"]');
      
      await usernameInput.fill('testuser');
      await expect(usernameInput).toHaveValue('testuser');
      
      await usernameInput.clear();
      await expect(usernameInput).toHaveValue('');
      
      await usernameInput.fill('newuser');
      await expect(usernameInput).toHaveValue('newuser');
    });
  });

  test.describe('3. Password Field Validation', () => {

    test('3.1 - Enter password in password field', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const passwordInput = modal.locator('input[type="password"]');
      
      await passwordInput.click();
      await expect(passwordInput).toBeFocused();
      
      await passwordInput.fill('Password123!');
      await expect(passwordInput).toHaveAttribute('type', 'password');
    });

    test('3.2 - Password field masks input for security', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const passwordInput = modal.locator('input[type="password"]');
      
      await passwordInput.fill('MySecurePassword');
      
      await expect(passwordInput).toHaveAttribute('type', 'password');
      await expect(passwordInput).toHaveValue('MySecurePassword');
    });

    test('3.3 - Clear and re-enter password', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const passwordInput = modal.locator('input[type="password"]');
      
      await passwordInput.fill('FirstPassword');
      await expect(passwordInput).toHaveValue('FirstPassword');
      
      await passwordInput.clear();
      await expect(passwordInput).toHaveValue('');
      
      await passwordInput.fill('DifferentPassword');
      await expect(passwordInput).toHaveValue('DifferentPassword');
    });
  });

  test.describe('4. OTP Booking Checkbox', () => {

    test('4.1 - Toggle checkbox to checked', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const otpCheckbox = modal.locator('input[type="checkbox"]');
      
      await expect(otpCheckbox).not.toBeChecked();
      await otpCheckbox.check();
      await expect(otpCheckbox).toBeChecked();
    });

    test('4.2 - Uncheck OTP checkbox', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const otpCheckbox = modal.locator('input[type="checkbox"]');
      
      await otpCheckbox.check();
      await expect(otpCheckbox).toBeChecked();
      
      await otpCheckbox.uncheck();
      await expect(otpCheckbox).not.toBeChecked();
    });
  });

  test.describe('5. Accessibility Features', () => {

    test('5.1 - Verify visually impaired user message', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const accessibilityMessage = modal.locator('text=/Visually impaired users.*OTP.*CAPTCHA/i');
      
      await expect(accessibilityMessage).toBeVisible();
    });
  });

  test.describe('6. Login Button Functionality', () => {

    test('6.1 - SIGN IN button visibility and state', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const signInButton = modal.locator('button:has-text("SIGN IN")');
      
      await expect(signInButton).toBeVisible();
      await expect(signInButton).toBeEnabled();
    });

    test('6.2 - Login with filled credentials', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const usernameInput = modal.locator('input[type="text"]');
      const passwordInput = modal.locator('input[type="password"]');
      const signInButton = modal.locator('button:has-text("SIGN IN")');
      
      await usernameInput.fill('testuser');
      await expect(usernameInput).toHaveValue('testuser');
      
      await passwordInput.fill('TestPassword123');
      await expect(passwordInput).toHaveValue('TestPassword123');
      
      await page.waitForTimeout(500);
    });
  });

  test.describe('7. Additional Login Options', () => {

    test('7.1 - Forgot Account Details link visible', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const forgotLink = modal.locator('text=FORGOT ACCOUNT DETAILS');
      
      await expect(forgotLink).toBeVisible();
      await expect(forgotLink).toBeEnabled();
    });

    test('7.2 - Register option visible', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const registerBtn = modal.locator('text=REGISTER');
      
      await expect(registerBtn).toBeVisible();
    });

    test('7.3 - Agent Login option visible', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const agentLoginBtn = modal.locator('text=AGENT LOGIN');
      
      await expect(agentLoginBtn).toBeVisible();
    });
  });

  test.describe('8. Form Field Interaction', () => {

    test('8.1 - Tab navigation between fields', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const usernameInput = modal.locator('input[type="text"]');
      const passwordInput = modal.locator('input[type="password"]');
      const otpCheckbox = modal.locator('input[type="checkbox"]');
      
      await usernameInput.click();
      await expect(usernameInput).toBeFocused();
      
      await usernameInput.press('Tab');
      await expect(passwordInput).toBeFocused();
      
      await passwordInput.press('Tab');
      await expect(otpCheckbox).toBeFocused();
    });

    test('8.2 - Enter key submits form', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const usernameInput = modal.locator('input[type="text"]');
      const passwordInput = modal.locator('input[type="password"]');
      
      await usernameInput.fill('testuser');
      await passwordInput.fill('TestPassword123');
      
      await passwordInput.press('Enter');
      await page.waitForTimeout(500);
    });
  });

  test.describe('9. Modal Closure and Re-opening', () => {

    test('9.1 - Close and reopen modal', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      await expect(modal).toBeVisible();
      
      await page.keyboard.press('Escape');
      await page.waitForTimeout(500);
      
      await expect(modal).toBeHidden({ timeout: 2000 });
      
      await loginLink.click();
      await expect(modal).toBeVisible();
    });
  });

  test.describe('10. Form Reset and Data Retention', () => {

    test('10.1 - Form clears after modal close and reopen', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const usernameInput = modal.locator('input[type="text"]');
      const passwordInput = modal.locator('input[type="password"]');
      
      await usernameInput.fill('testuser');
      await expect(usernameInput).toHaveValue('testuser');
      
      await passwordInput.fill('TestPassword123');
      await expect(passwordInput).toHaveValue('TestPassword123');
      
      await page.keyboard.press('Escape');
      await page.waitForTimeout(500);
      
      await expect(modal).toBeHidden({ timeout: 2000 });
      
      await loginLink.click();
      await page.waitForTimeout(500);
      
      await expect(modal).toBeVisible();
      await expect(usernameInput).toHaveValue('');
      await expect(passwordInput).toHaveValue('');
    });

    test('10.2 - OTP checkbox resets after modal close', async ({ page }) => {
      await page.goto('https://www.irctc.co.in/nget/train-search');
      
      const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
      await loginLink.click();
      
      const modal = page.locator('[role="dialog"]');
      const otpCheckbox = modal.locator('input[type="checkbox"]');
      
      await otpCheckbox.check();
      await expect(otpCheckbox).toBeChecked();
      
      await page.keyboard.press('Escape');
      await page.waitForTimeout(500);
      
      await expect(modal).toBeHidden({ timeout: 2000 });
      
      await loginLink.click();
      await page.waitForTimeout(500);
      
      await expect(modal).toBeVisible();
      await expect(otpCheckbox).not.toBeChecked();
    });
  });
});
