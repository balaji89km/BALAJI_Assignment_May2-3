// spec: specs/irctc-login-test-plan.md
// seed: seed.spec.ts

import { test, expect } from '@playwright/test';

test.describe('Login Modal Interaction', () => {
  
  test('1.1 Open login modal successfully', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // Homepage loads successfully with train booking interface visible
    await expect(page).toHaveURL('https://www.irctc.co.in/nget/train-search');
    const searchButton = page.locator('button:has-text("Search Trains")');
    await expect(searchButton).toBeVisible();
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await expect(loginLink).toBeVisible();
    await loginLink.click();
    
    // Login modal appears with login form visible
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // Verify SIGN IN button is visible in modal
    const signInButton = modal.locator('button:has-text("SIGN IN")');
    await expect(signInButton).toBeVisible();
  });

  test('1.2 Verify login form elements are present', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    await expect(page).toHaveURL('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal displays with all form elements
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // Username input field (placeholder: "User Name")
    const usernameInput = modal.locator('input[type="text"]');
    await expect(usernameInput).toBeVisible();
    await expect(usernameInput).toHaveAttribute('placeholder', 'User Name');
    
    // Password input field (placeholder: "Password")
    const passwordInput = modal.locator('input[type="password"]');
    await expect(passwordInput).toBeVisible();
    await expect(passwordInput).toHaveAttribute('placeholder', 'Password');
    
    // "Booking using OTP" checkbox
    const otpCheckbox = modal.locator('input[type="checkbox"]');
    await expect(otpCheckbox).toBeVisible();
    
    // "SIGN IN" button
    const signInButton = modal.locator('button:has-text("SIGN IN")');
    await expect(signInButton).toBeVisible();
    
    // "FORGOT ACCOUNT DETAILS?" link
    await expect(modal.locator('text=FORGOT ACCOUNT DETAILS')).toBeVisible();
    
    // "REGISTER" button or link
    await expect(modal.locator('text=REGISTER')).toBeVisible();
    
    // "AGENT LOGIN" button
    await expect(modal.locator('text=AGENT LOGIN')).toBeVisible();
    
    // Verify accessibility message is displayed
    await expect(modal.locator('text=Visually impaired')).toBeVisible();
  });
});
