// spec: specs/irctc-login-test-plan.md
// seed: seed.spec.ts

import { test, expect } from '@playwright/test';

test.describe('Additional Login Options', () => {

  test('7.1 Access Forgot Account Details link', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Click on "FORGOT ACCOUNT DETAILS?" link
    const forgotLink = modal.locator('text=FORGOT ACCOUNT DETAILS');
    await expect(forgotLink).toBeVisible();
    
    // Verify the link exists and is clickable
    await expect(forgotLink).toBeEnabled();
  });

  test('7.2 Access Register option', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Verify REGISTER button or link exists
    const registerBtn = modal.locator('text=REGISTER');
    
    // Registration page or form appears
    await expect(registerBtn).toBeVisible();
  });

  test('7.3 Access Agent Login option', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Verify AGENT LOGIN button exists
    const agentLoginBtn = modal.locator('text=AGENT LOGIN');
    
    // Agent login page or form appears
    await expect(agentLoginBtn).toBeVisible();
  });
});

test.describe('Form Field Interaction Scenarios', () => {

  test('8.1 Tab navigation between fields', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    const usernameInput = modal.locator('input[type="text"]');
    const passwordInput = modal.locator('input[type="password"]');
    const otpCheckbox = modal.locator('input[type="checkbox"]');
    
    // 3. Click in the Username field
    await usernameInput.click();
    
    // Username field is focused
    await expect(usernameInput).toBeFocused();
    
    // 4. Press Tab key to move to Password field
    await usernameInput.press('Tab');
    
    // Focus moves to Password field
    await expect(passwordInput).toBeFocused();
    
    // 5. Press Tab key again to move to OTP checkbox
    await passwordInput.press('Tab');
    
    // Focus moves to OTP checkbox or next focusable element
    await expect(otpCheckbox).toBeFocused();
  });

  test('8.2 Keyboard submission with Enter key', async ({ page }) => {
    // 1. Navigate to https://www.irctc.co.in/nget/train-search
    await page.goto('https://www.irctc.co.in/nget/train-search');
    
    // 2. Click on "LOGIN / REGISTER" button
    const loginLink = page.locator('a:has-text("LOGIN / REGISTER")').first();
    await loginLink.click();
    
    // Login modal appears
    const modal = page.locator('[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // 3. Enter 'testuser' in the Username field
    const usernameInput = modal.locator('input[type="text"]');
    await usernameInput.fill('testuser');
    
    // Username field displays 'testuser'
    await expect(usernameInput).toHaveValue('testuser');
    
    // 4. Enter 'TestPassword123' in the Password field
    const passwordInput = modal.locator('input[type="password"]');
    await passwordInput.fill('TestPassword123');
    
    // Password field is masked
    await expect(passwordInput).toHaveValue('TestPassword123');
    
    // 5. Press Enter key
    // Form submission is attempted
    await passwordInput.press('Enter');
    
    // Wait a moment for any submission processing
    await page.waitForTimeout(500);
  });
});
