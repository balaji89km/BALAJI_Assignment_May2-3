# RoboForm Filling Test Form - Complete Test Plan

## Application Overview


This test plan covers comprehensive testing of the RoboForm filling test form at https://www.roboform.com/filling-test-all-fields. This is a form filler demonstration page that contains a wide variety of input fields including text inputs, dropdowns, and date selectors. The form is designed for testing form automation tools like RoboForm and contains no submit button. The primary objective is to ensure all form fields accept and retain user input correctly, and that the reset functionality works as expected.


## Test Scenarios

### 1. Personal Information Fields

**Seed:** `seed.spec.ts`

#### 1.1. Fill basic personal information fields

**File:** `specs/personal-info/basic-personal-info.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully with form visible
  2. Enter 'Mr.' in the Title field
    - expect: Title field displays 'Mr.'
  3. Enter 'John' in the First Name field
    - expect: First Name field displays 'John'
  4. Enter 'A' in the Middle Initial field
    - expect: Middle Initial field displays 'A'
  5. Enter 'Smith' in the Last Name field
    - expect: Last Name field displays 'Smith'
  6. Enter 'John A Smith' in the Full Name field
    - expect: Full Name field displays 'John A Smith'

#### 1.2. Fill company and position fields

**File:** `specs/personal-info/company-position.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter 'Tech Solutions Inc' in the Company field
    - expect: Company field displays 'Tech Solutions Inc'
  3. Enter 'Senior Software Engineer' in the Position field
    - expect: Position field displays 'Senior Software Engineer'

### 2. Address Fields

**Seed:** `seed.spec.ts`

#### 2.1. Fill complete address information

**File:** `specs/address/complete-address.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter '123 Main Street' in Address Line 1
    - expect: Address Line 1 displays '123 Main Street'
  3. Enter 'Apartment 4B' in Address Line 2
    - expect: Address Line 2 displays 'Apartment 4B'
  4. Enter 'San Francisco' in City
    - expect: City displays 'San Francisco'
  5. Enter 'CA' in State/Province
    - expect: State/Province displays 'CA'
  6. Enter 'United States' in Country
    - expect: Country displays 'United States'
  7. Enter '94102' in Zip
    - expect: Zip field displays '94102'

#### 2.2. Test address fields with special characters

**File:** `specs/address/special-chars-address.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter '123 O'Connor Street' in Address Line 1
    - expect: Address Line 1 handles apostrophes correctly
  3. Enter 'Apt. #5' in Address Line 2
    - expect: Address Line 2 handles special characters and numbers
  4. Enter 'Saint-Hyacinthe' in City
    - expect: City handles hyphens correctly

### 3. Contact Information Fields

**Seed:** `seed.spec.ts`

#### 3.1. Fill phone number fields

**File:** `specs/contact-info/phone-numbers.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter '(555) 123-4567' in Home Phone
    - expect: Home Phone displays '(555) 123-4567'
  3. Enter '(555) 987-6543' in Work Telephone
    - expect: Work Telephone displays '(555) 987-6543'
  4. Enter '(555) 456-7890' in Fax
    - expect: Fax displays '(555) 456-7890'
  5. Enter '(555) 111-2222' in Cell Phone
    - expect: Cell Phone displays '(555) 111-2222'

#### 3.2. Fill email and website fields

**File:** `specs/contact-info/email-website.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter 'john.smith@example.com' in E-mail
    - expect: E-mail displays 'john.smith@example.com'
  3. Enter 'https://www.johnsmith.com' in Web Site
    - expect: Web Site displays 'https://www.johnsmith.com'

### 4. Account Credentials Fields

**Seed:** `seed.spec.ts`

#### 4.1. Fill user ID and password fields

**File:** `specs/credentials/user-password.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter 'jsmith' in User ID
    - expect: User ID displays 'jsmith'
  3. Enter 'SecurePass123!' in Password field
    - expect: Password field contains the entered value

### 5. Credit Card Fields

**Seed:** `seed.spec.ts`

#### 5.1. Fill credit card information with Visa selection

**File:** `specs/credit-card/visa-card.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Click on Credit Card Type dropdown
    - expect: Dropdown opens showing card options
  3. Select 'Visa (Preferred)' from the dropdown
    - expect: Visa (Preferred) is selected in the dropdown
  4. Enter '4532123456789010' in Credit Card Number
    - expect: Credit Card Number displays '4532123456789010'
  5. Enter '123' in Card Verification Code
    - expect: Card Verification Code displays '123'

#### 5.2. Test all credit card type options

**File:** `specs/credit-card/all-card-types.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Click on Credit Card Type dropdown and select 'Master Card'
    - expect: Master Card is selected
  3. Click on Credit Card Type dropdown and select 'American Express'
    - expect: American Express is selected
  4. Click on Credit Card Type dropdown and select 'Discover'
    - expect: Discover is selected
  5. Click on Credit Card Type dropdown and select 'Diners Club'
    - expect: Diners Club is selected

#### 5.3. Fill card expiration date and cardholder info

**File:** `specs/credit-card/card-expiration.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Click on Card Expiration Date Month dropdown and select '12'
    - expect: Month dropdown shows '12'
  3. Click on Card Expiration Date Year dropdown and select '2026'
    - expect: Year dropdown shows '2026'
  4. Enter 'John A Smith' in Card User Name
    - expect: Card User Name displays 'John A Smith'
  5. Enter 'First National Bank' in Card Issuing Bank
    - expect: Card Issuing Bank displays 'First National Bank'
  6. Enter '1-800-555-1234' in Card Customer Service Phone
    - expect: Card Customer Service Phone displays '1-800-555-1234'

### 6. Personal Identity Fields

**Seed:** `seed.spec.ts`

#### 6.1. Fill sex and identification numbers

**File:** `specs/identity/identification.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter 'M' in Sex field
    - expect: Sex field displays 'M'
  3. Enter '123-45-6789' in Social Security Number
    - expect: Social Security Number displays '123-45-6789'
  4. Enter 'D1234567' in Driver License Number
    - expect: Driver License Number displays 'D1234567'

#### 6.2. Fill date of birth with all dropdown options

**File:** `specs/identity/date-of-birth.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Click on Date Of Birth Month dropdown and select 'May'
    - expect: Month dropdown shows 'May'
  3. Click on Date Of Birth Day dropdown and select '15'
    - expect: Day dropdown shows '15'
  4. Click on Date Of Birth Year dropdown and select '1990'
    - expect: Year dropdown shows '1990'

#### 6.3. Fill age and personal details

**File:** `specs/identity/age-details.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter '34' in Age field
    - expect: Age field displays '34'
  3. Enter 'New York, USA' in Birth Place
    - expect: Birth Place displays 'New York, USA'
  4. Enter '$125000' in Income
    - expect: Income field displays '$125000'

### 7. Message and Comment Fields

**Seed:** `seed.spec.ts`

#### 7.1. Fill message and comment fields with text content

**File:** `specs/messages/message-comments.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter 'Hello from RoboForm test' in Custom Message
    - expect: Custom Message displays 'Hello from RoboForm test'
  3. Enter 'This is a test comment for form filling validation' in Comments
    - expect: Comments field displays the full text

#### 7.2. Test multiline text in comment fields

**File:** `specs/messages/multiline-comments.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter multiline text with line breaks in Comments field
    - expect: Comments field preserves line breaks and formatting

### 8. Form Reset and Validation

**Seed:** `seed.spec.ts`

#### 8.1. Verify reset button clears all fields

**File:** `specs/form-actions/reset-form.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully with empty form
  2. Fill multiple fields with data (Title, First Name, Email, etc.)
    - expect: All fields display the entered data
  3. Click the Reset button
    - expect: All text input fields are cleared
    - expect: Dropdown fields return to default selections
    - expect: Form returns to initial empty state

#### 8.2. Test reset on partially filled form

**File:** `specs/form-actions/partial-reset.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Fill only 5 fields (Title, First Name, Company, Email, Age)
    - expect: Only those 5 fields contain data
  3. Click Reset button
    - expect: All fields are cleared
    - expect: Form is completely reset

### 9. Full Form Filling Scenarios

**Seed:** `seed.spec.ts`

#### 9.1. Complete form filling with all fields

**File:** `specs/full-form/complete-fill.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Fill Title with 'Mr.'
    - expect: Title field shows 'Mr.'
  3. Fill First Name with 'Robert'
    - expect: First Name field shows 'Robert'
  4. Fill Middle Initial with 'J'
    - expect: Middle Initial shows 'J'
  5. Fill Last Name with 'Johnson'
    - expect: Last Name shows 'Johnson'
  6. Fill Full Name with 'Robert J Johnson'
    - expect: Full Name shows 'Robert J Johnson'
  7. Fill Company with 'Global Tech Corp'
    - expect: Company shows 'Global Tech Corp'
  8. Fill Position with 'Director'
    - expect: Position shows 'Director'
  9. Fill Address Line 1 with '456 Oak Boulevard'
    - expect: Address Line 1 shows '456 Oak Boulevard'
  10. Fill Address Line 2 with 'Suite 200'
    - expect: Address Line 2 shows 'Suite 200'
  11. Fill City with 'Boston'
    - expect: City shows 'Boston'
  12. Fill State/Province with 'MA'
    - expect: State/Province shows 'MA'
  13. Fill Country with 'United States'
    - expect: Country shows 'United States'
  14. Fill Zip with '02101'
    - expect: Zip shows '02101'
  15. Fill Home Phone with '(617) 555-1000'
    - expect: Home Phone shows '(617) 555-1000'
  16. Fill Work Telephone with '(617) 555-2000'
    - expect: Work Telephone shows '(617) 555-2000'
  17. Fill Fax with '(617) 555-3000'
    - expect: Fax shows '(617) 555-3000'
  18. Fill Cell Phone with '(617) 555-4000'
    - expect: Cell Phone shows '(617) 555-4000'
  19. Fill E-mail with 'rjohnson@globaltech.com'
    - expect: E-mail shows 'rjohnson@globaltech.com'
  20. Fill Web Site with 'https://www.globaltech.com'
    - expect: Web Site shows 'https://www.globaltech.com'
  21. Fill User ID with 'rjohnson'
    - expect: User ID shows 'rjohnson'
  22. Fill Password with 'MyPassword123!'
    - expect: Password field contains the value
  23. Select 'Master Card' from Credit Card Type
    - expect: Master Card is selected
  24. Fill Credit Card Number with '5425233010103442'
    - expect: Credit Card Number shows '5425233010103442'
  25. Fill Card Verification Code with '321'
    - expect: Card Verification Code shows '321'
  26. Select '09' for Card Expiration Month
    - expect: Month dropdown shows '09'
  27. Select '2028' for Card Expiration Year
    - expect: Year dropdown shows '2028'
  28. Fill Card User Name with 'Robert J Johnson'
    - expect: Card User Name shows 'Robert J Johnson'
  29. Fill Card Issuing Bank with 'Chase Bank'
    - expect: Card Issuing Bank shows 'Chase Bank'
  30. Fill Card Customer Service Phone with '1-800-935-9935'
    - expect: Card Customer Service Phone shows '1-800-935-9935'
  31. Fill Sex with 'Male'
    - expect: Sex field shows 'Male'
  32. Fill Social Security Number with '456-78-9012'
    - expect: Social Security Number shows '456-78-9012'
  33. Fill Driver License Number with 'MA123456'
    - expect: Driver License Number shows 'MA123456'
  34. Select 'Jun' for Date of Birth Month
    - expect: Month dropdown shows 'Jun'
  35. Select '20' for Date of Birth Day
    - expect: Day dropdown shows '20'
  36. Select '1985' for Date of Birth Year
    - expect: Year dropdown shows '1985'
  37. Fill Age with '41'
    - expect: Age field shows '41'
  38. Fill Birth Place with 'Chicago, Illinois'
    - expect: Birth Place shows 'Chicago, Illinois'
  39. Fill Income with '$250000'
    - expect: Income field shows '$250000'
  40. Fill Custom Message with 'Automated form fill test completed successfully'
    - expect: Custom Message shows the full text
  41. Fill Comments with 'All fields have been populated with test data'
    - expect: Comments field shows the full text

#### 9.2. Fill form and verify data persistence

**File:** `specs/full-form/data-persistence.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Fill multiple fields with test data
    - expect: All fields display entered data
  3. Scroll through the form to review all entries
    - expect: All previously filled fields retain their data
  4. Click on the first field (Title) and verify it still contains data
    - expect: Field maintains its value

### 10. Edge Cases and Special Characters

**Seed:** `seed.spec.ts`

#### 10.1. Test text fields with special characters

**File:** `specs/edge-cases/special-characters.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter 'O'Brien' in Last Name (with apostrophe)
    - expect: Last Name field handles apostrophes
  3. Enter '123@456' in User ID (with special character)
    - expect: User ID field accepts special characters
  4. Enter 'Street & Avenue' in Address Line 1 (with ampersand)
    - expect: Address field handles ampersands correctly
  5. Enter 'São Paulo' in City (with accented characters)
    - expect: City field supports international characters

#### 10.2. Test numeric field boundaries

**File:** `specs/edge-cases/numeric-boundaries.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter '999' in Card Verification Code
    - expect: Card Verification Code accepts the value
  3. Enter '0' in Age field
    - expect: Age field accepts zero
  4. Enter '9999999999' in Cell Phone
    - expect: Cell Phone field accepts numeric values

#### 10.3. Test very long text input

**File:** `specs/edge-cases/long-text.spec.ts`

**Steps:**
  1. Navigate to https://www.roboform.com/filling-test-all-fields
    - expect: Page loads successfully
  2. Enter a 100+ character string in Custom Message field
    - expect: Field accepts long text input
  3. Enter a very long string (200+ characters) in Comments field
    - expect: Comments field handles extended text
