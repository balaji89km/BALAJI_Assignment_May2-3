# IRCTC Login Page - Comprehensive Test Plan

## Application Overview

This test plan covers comprehensive testing of the IRCTC (Indian Railway Catering & Tourism Corporation) Login page at https://www.irctc.co.in/nget/train-search. The login modal is accessed through a "LOGIN / REGISTER" button on the train search homepage. The application provides authentication functionality for users to access their booking and account information.

## Test Scenarios

### 1. Login Modal Interaction

**Seed:** `seed.spec.ts`

#### 1.1 Open login modal successfully

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully with train booking interface visible
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears with login form visible

#### 1.2 Verify login form elements are present

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal displays with all form elements:
      - Username input field (placeholder: "User Name")
      - Password input field (placeholder: "Password")
      - "Booking using OTP" checkbox
      - "SIGN IN" button
      - "FORGOT ACCOUNT DETAILS?" link
      - "REGISTER" button for new users
      - "AGENT LOGIN" button for agents

### 2. Username Field Validation

**Seed:** `seed.spec.ts`

#### 2.1 Enter valid username format

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Click in the Username field
    - expect: Username input field is focused
  4. Enter 'testuser123' in the Username field
    - expect: Username field displays 'testuser123'

#### 2.2 Username field accepts various character types

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Enter 'user.test@2024' in the Username field
    - expect: Username field displays 'user.test@2024'

#### 2.3 Clear and re-enter username

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Enter 'testuser' in the Username field
    - expect: Username field displays 'testuser'
  4. Clear the Username field
    - expect: Username field is now empty
  5. Enter 'newuser' in the Username field
    - expect: Username field displays 'newuser'

### 3. Password Field Validation

**Seed:** `seed.spec.ts`

#### 3.1 Enter password in password field

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Click in the Password field
    - expect: Password input field is focused
  4. Enter 'Password123!' in the Password field
    - expect: Password field is masked/hidden (shows dots or bullets)

#### 3.2 Password field masks input for security

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Enter 'MySecurePassword' in the Password field
    - expect: Password characters are not visible in plain text
    - expect: Password field shows masked characters

#### 3.3 Clear and re-enter password

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Enter 'FirstPassword' in the Password field
    - expect: Password field is masked
  4. Clear the Password field
    - expect: Password field is now empty
  5. Enter 'DifferentPassword' in the Password field
    - expect: Password field is masked

### 4. OTP Booking Checkbox

**Seed:** `seed.spec.ts`

#### 4.1 Toggle "Booking using OTP" checkbox

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Verify "Booking using OTP" checkbox is unchecked initially
    - expect: Checkbox is in unchecked state
  4. Click on "Booking using OTP" checkbox
    - expect: Checkbox becomes checked

#### 4.2 Uncheck OTP checkbox

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Click on "Booking using OTP" checkbox to check it
    - expect: Checkbox is checked
  4. Click on "Booking using OTP" checkbox again to uncheck it
    - expect: Checkbox is unchecked

### 5. Accessibility Features

**Seed:** `seed.spec.ts`

#### 5.1 Verify visually impaired user OTP option

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Verify accessibility message is visible: "Visually impaired users may select this option to receive OTP instead of CAPTCHA"
    - expect: Accessibility message is displayed on the form

### 6. Login Button Functionality

**Seed:** `seed.spec.ts`

#### 6.1 Sign In button state and visibility

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Verify "SIGN IN" button is visible
    - expect: "SIGN IN" button is displayed and clickable

#### 6.2 Login with credentials filled

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Enter 'testuser' in the Username field
    - expect: Username field displays 'testuser'
  4. Enter 'TestPassword123' in the Password field
    - expect: Password field is masked
  5. Click on "SIGN IN" button
    - expect: Form submission is attempted (may show validation errors or proceed based on credentials)

### 7. Additional Options

**Seed:** `seed.spec.ts`

#### 7.1 Access Forgot Account Details link

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Click on "FORGOT ACCOUNT DETAILS?" link
    - expect: Forgot account details page/modal appears or new tab opens

#### 7.2 Access Register option

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Click on "REGISTER" button or link
    - expect: Registration page or form appears

#### 7.3 Access Agent Login option

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Click on "AGENT LOGIN" button
    - expect: Agent login page or form appears

### 8. Form Field Interaction Scenarios

**Seed:** `seed.spec.ts`

#### 8.1 Tab navigation between fields

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Click in the Username field
    - expect: Username field is focused
  4. Press Tab key
    - expect: Focus moves to Password field
  5. Press Tab key again
    - expect: Focus moves to OTP checkbox or next focusable element

#### 8.2 Keyboard submission with Enter key

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Enter 'testuser' in the Username field
    - expect: Username field displays 'testuser'
  4. Enter 'TestPassword123' in the Password field
    - expect: Password field is masked
  5. Press Enter key
    - expect: Form submission is attempted

### 9. Modal Closure and Re-opening

**Seed:** `seed.spec.ts`

#### 9.1 Close login modal and reopen

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Close the login modal (click close button or outside modal)
    - expect: Login modal closes and returns to homepage
  4. Click on "LOGIN / REGISTER" button again
    - expect: Login modal appears again with empty form fields

### 10. Form Reset and Data Retention

**Seed:** `seed.spec.ts`

#### 10.1 Verify form clears after modal close and reopen

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Enter 'testuser' in the Username field
    - expect: Username field displays 'testuser'
  4. Enter 'TestPassword123' in the Password field
    - expect: Password field is masked
  5. Close the login modal
    - expect: Login modal closes
  6. Click on "LOGIN / REGISTER" button again
    - expect: Login modal appears with empty form fields
    - expect: Username field is empty
    - expect: Password field is empty

#### 10.2 OTP checkbox state after modal close

**Steps:**
  1. Navigate to https://www.irctc.co.in/nget/train-search
    - expect: Homepage loads successfully
  2. Click on "LOGIN / REGISTER" button
    - expect: Login modal appears
  3. Check the "Booking using OTP" checkbox
    - expect: Checkbox is checked
  4. Close the login modal
    - expect: Login modal closes
  5. Click on "LOGIN / REGISTER" button again
    - expect: Login modal appears
    - expect: "Booking using OTP" checkbox is unchecked (reset to default state)

## Test Execution Notes

- All tests should verify the IRCTC login modal functionality
- Tests should validate form field input acceptance and behavior
- Tests should verify keyboard navigation and accessibility features
- Tests should confirm proper modal state management (open/close/reopen)
- Tests should validate form data clearing after modal closure
- Tests should check for proper focus management and tab order
- Performance: Modal should appear within 2 seconds of clicking LOGIN button
- Accessibility: All form elements should be keyboard accessible
- Compatibility: Tests should work across major browsers (Chrome, Firefox, Safari, Edge)
